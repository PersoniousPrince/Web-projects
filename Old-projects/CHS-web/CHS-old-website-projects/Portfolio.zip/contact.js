const darkTheme = document.getElementById(`themeButton`);
const body = document.body;

darkTheme.addEventListener(`click`, () => {
    const isDark = body.classList.toggle(`dark-mode`);

    if (isDark){
        darkTheme.textContent = `Light Mode`;
    } else {
        darkTheme.textContent = `Dark Mode`;
    }
});

const hrs = document.getElementById(`hrs`);
const mins = document.getElementById(`mins`);
const secs = document.getElementById(`secs`);

const formatTime = (value) => {
    return value < 10 ? `0${value}` : `${value}`;
}

setInterval(() => {
    const currentTime = new Date();

    hrs.innerHTML = formatTime(currentTime.getHours());
    mins.innerHTML = formatTime(currentTime.getMinutes());
    secs.innerHTML = formatTime(currentTime.getSeconds());

}, 1000);