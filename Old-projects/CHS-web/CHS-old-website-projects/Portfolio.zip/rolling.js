const myButton = document.getElementById(`myButton`);
const label1= document.getElementById(`label1`);
let randomNum;
let min = 1;
let max = 6;

myButton.onclick = function() {
    randomNum = Math.floor(Math.random()*(max)+min);
    label1.textContent = randomNum;
}