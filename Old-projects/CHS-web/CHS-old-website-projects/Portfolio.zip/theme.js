const toggleTheme = document.getElementById(`themeButton`);
const body = document.body;

toggleTheme.addEventListener(`click`, () =>{
    const isDarkMode = body.classList.toggle(`darkMode`);

    if(isDarkMode){
        toggleTheme.textContent = `Light Mode`;
    } else {
        toggleTheme.textContent = `Dark Mode`;
    }
});