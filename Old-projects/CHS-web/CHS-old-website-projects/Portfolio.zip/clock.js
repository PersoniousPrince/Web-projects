const hrs = document.getElementById('hrs');
const min = document.getElementById('min');
const sec = document.getElementById('sec');

const formatTime = (value) => {
  return value < 10 ? `0${value}` : `${value}`;
}

setInterval(() => {
  let currentTime = new Date();

  hrs.innerHTML = formatTime(currentTime.getHours());
  min.innerHTML = formatTime(currentTime.getMinutes());
  sec.innerHTML = formatTime(currentTime.getSeconds());
}, 1000);