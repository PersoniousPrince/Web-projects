const display = document.getElementById("displayInput");

const clearDisplay = () => {
  display.value = "";
};

const appendToDisplay = (input) => {
  display.value += input;
};

const calculate = () => {
  try {
    display.value = eval(display.value);
  } catch (error) {
    display.value = "Error";
  }
};